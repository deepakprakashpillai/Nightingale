from django.apps import AppConfig


class HospitalmanagementConfig(AppConfig):
    name = 'hospitalmanagement'
